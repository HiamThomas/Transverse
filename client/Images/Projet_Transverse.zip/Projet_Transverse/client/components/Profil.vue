<template v-if="user.id !== undefined">
  <div>
      <div class="block_button_menu">
       <router-link class="button_menu" data-aos="zoom-in" data-aos-duration="1000" to='/'>Accueil</router-link>
        <p class="button_menu" data-aos="zoom-in">|</p>
        <router-link v-if="user.id == undefined" class="button_menu" data-aos="zoom-in" data-aos-duration="1000" to='/login'>Connect</router-link>
        <router-link v-else class="button_menu" data-aos="zoom-in" data-aos-duration="1000" to='/profil'>Profil</router-link>
        <p class="button_menu" data-aos="zoom-in">|</p>
        <router-link class="button_menu" data-aos="zoom-in" data-aos-duration="1000" to='/'>About</router-link>
        <p class="button_menu" data-aos="zoom-in">|</p>
        <router-link v-if="user.id != undefined" class="button_menu" data-aos="zoom-in" data-aos-duration="1000" to='/games'>Games</router-link>
      </div>
      
      <div class="container2">
        <div class="text1">
          <div class="image_profil"></div>
          <h2 class="username">{{this.user.username}}</h2>
          <button @click="logout()" class="btn max_width1 effect01"><span>Deconnexion</span></button>
          <p class="description_profil">{{this.user.description}}</p>
          <h2 class="titre_jeux">Jeux :</h2>
          <div class="games_list">
            <p class="game_item" v-for="item in user.games" :key="item">
              {{ item }}
            </p>
          </div>
        </div>
        <div class="text2">
          <h3>Information</h3>
          <div class="flexbox_information">
            <div class="item_flexbox">
              <p class="titre_description">AGE</p><br>
              <p>{{this.user.age}}</p>
            </div>
            <div class="item_flexbox">
              <p class="titre_description">NATIONALITE</p><br>
              <p>{{this.user.nationality}}</p>
            </div>
            <div class="item_flexbox">
              <p class="titre_description">LANGUE</p><br>
              <p>{{this.user.language}}</p>
            </div>
            <div class="item_flexbox">
              <p class="titre_description">DISCORD</p><br>
              <p>test2#9556</p>
            </div>
            <div class="item_flexbox">
              <p class="titre_description">RANKING  </p><br>
              <span class="fa fa-star checked"></span>
              <span class="fa fa-star checked"></span>
              <span class="fa fa-star checked"></span>
              <span class="fa fa-star"></span>
              <span class="fa fa-star"></span>
            </div>
            <div class="item_flexbox">
              <p class="titre_description">LEVEL</p><br>
              <p>12</p>
            </div>
            <div class="item_flexbox">
              <p class="titre_description">JEU PRINCIPAL</p><br>
              <p>{{this.user.main_game}}</p>
            </div>
            <div class="item_flexbox">
              <p class="titre_description">PSEUDO {{this.user.main_game}}</p><br>
              <p>{{this.user.main_game}}</p>
            </div>
          </div>
        </div>
        <div class="text3">
        </div>
      </div>
  </div>
    
</template>


<script>
module.exports = {
  props: {
    user:{type: Object}
  },
  data() {
    return {
    };
  },
  mounted() {
  },
  methods: {
    logout(){
       this.$emit('logout')
    }
  }
};
</script>