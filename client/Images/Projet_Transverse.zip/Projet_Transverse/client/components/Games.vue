<template>
  <div>
    <div class="block1">
    <header>
      <div class="block_button_menu white">
        <router-link class="button_menu" data-aos="zoom-in" data-aos-duration="1000" to='/'>Accueil</router-link>
        <p class="button_menu" data-aos="zoom-in">|</p>
        <router-link v-if="user.id == undefined" class="button_menu" data-aos="zoom-in" data-aos-duration="1000" to='/login'>Connect</router-link>
        <router-link v-else class="button_menu" data-aos="zoom-in" data-aos-duration="1000" to='/profil'>Profil</router-link>
        <p class="button_menu" data-aos="zoom-in">|</p>
        <router-link class="button_menu" data-aos="zoom-in" data-aos-duration="1000" to='/'>About</router-link>
        <p class="button_menu" data-aos="zoom-in">|</p>
        <router-link v-if="user.id != undefined" class="button_menu" data-aos="zoom-in" data-aos-duration="1000" to='/games'>Games</router-link>
      </div>
    </header>
    <section>
        <br><br><br>
        <div v-for="game in games" :key="game.id" class="card img-fluid">
        <img class="card-img-top" v-bind:src="game.image" alt="Card image" />
        <div class="card-img-overlay">
          <div class="absolute card-body-libelle">
            {{ game.name }}
            <hr />
                <span @click="navigate(game.id)"  class="fa fa-comments"></span> |
                <span  @click="addToListGames(game.id)" class="fa fa-heart-o"></span>

          </div>
        </div>
      </div>
    </section>
    
    
    <footer>Copyright © 2020. All rights reserved.</footer>
  </div>
</template>

<script>

module.exports = {
  props: {
      user:{type: Object}
  },
  data() {
    return {
        games: [],
    };
  },
  methods: {
    fonction_scroll(){
      window.scrollTo({top:1000, left:0})
    },
    navigate(id){
        window.location.href = '#/tchat/'+id;
    },
async addToListGames(gameId){
        const res = await axios.post('/api/addToListGames', { userId: this.user.id, gameId: gameId }).then((result) => {
            alert("Ajout dans la liste effectuée");
        }).catch((err) => {
            alert("Echec lors de l'enregistrement");
        });
  },
  
},
  async created() {
     const res = await axios.get('/api/games')
    this.games = res.data;
    console.log(this.games);
  },

};
</script>

<style scope>

    .img-fluid:hover img {
        transform: scale(1.5);
        filter: brightness(90%) blur(0px);
    }

    .img-fluid img {
        transition: transform 1s ease;
    }

    .img-fluid {
        position: relative;
        width: 250px;
        height: 300px;
        overflow: hidden;
        border-radius: 7px;
        display: inline-block;
        margin:1%;
    }

    .card-img-top {
        position: relative;
        width: 100%;
        height: 100%;
    }

    .card-body-libelle {
        background: #484541a6;
        border-top-right-radius: 10px;
        border-top-left-radius: 10px;
        position: absolute;
        width: 90%;
        bottom: 10px;
        left: 5%;
        padding: 1%;
        border-bottom: 3px solid #FFF;
        text-align: center;
        color: white;
        font-weight: bold;
    }

        .card-body-libelle span {
            color: cyan;
        }

</style>


